//---------------------------------------------------------
// Author: Zain Raza
//
// RazaTask.java
// Represents an item on your to-do list.
//
// Due Date: Wednesday, December 5, 2018
//---------------------------------------------------------

public class RazaTask implements RazaPriority
{
// instance variables
	String item;
	private int priorityLevel;

// Constructor
public RazaTask(String item, int pL) 
{
	this.item = item;
	
	// default: all objects will initialize priorityLevel to a RazaPriority static variables
	if (pL < 5) 
	{
		priorityLevel = MIN;
	}
	else if (pL > 5)
	{
		priorityLevel = MAX;
	}
	else
	{
		priorityLevel = MED;
	}
}

//--------------------------------------------------------
// setPriority: allows programmer to change priorityLevel
// to any value they choose between 1-10
//--------------------------------------------------------
public void setPriority(int p)
{
	priorityLevel = p;
}

//------------------------------------------------
// getPriority: returns current priorityLevel
//------------------------------------------------
public int getPriority()
{
	return priorityLevel;
}

//--------------------------------------------
// outputName: outputs task name 
//--------------------------------------------
public String outputName()
{
	return item;
}

//--------------------------------------------
// outputPriority: outputs priorityLevel
//--------------------------------------------
public String outputPriority()
{
	return "priority: " + this.getPriority();
}

}