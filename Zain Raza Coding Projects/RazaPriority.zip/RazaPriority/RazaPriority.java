//----------------------------------------------------------------
// Author: Zain Raza
//
// RazaPriority.java
// An interface which represents the order of importance in
// which a set of tasks must be completed, on a scale of 1 to 10.
//
// Due Date: Wednesday, December 5, 2018
//----------------------------------------------------------------

public interface RazaPriority
{
	int MIN = 1;
	int MED = 5;
	int MAX = 10;
	
	void setPriority(int p);
	int getPriority();	
}