//---------------------------------------------------------
// Author: Zain Raza
//
// RazaTaskClient.java
// Demonstrates use of methods from the RazaTask class.
//
// Due Date: Wednesday, December 5, 2018
//---------------------------------------------------------

public class RazaTaskClient
{
	public static void main(String [] args)
	{
//------------------------------------------------------
// Represents a set of ordered tasks on a to-do list.
//------------------------------------------------------
		// instantiation of objects 
		RazaTask family = new RazaTask("Eat dinner with family", 3);
		RazaTask community = new RazaTask("Volunteer at GMS", 7);
		RazaTask business = new RazaTask("Talk to podcast sponsors", 9);
		RazaTask school = new RazaTask("Get a 5 on AP Exams", 4);
		
		// changes priority level on two objects
		school.setPriority(4);
		community.setPriority(7);
		
		//outputting to-do list
		System.out.println("\t TO-DO \t");
		System.out.println("-----------------------");
		System.out.println(family.outputName() + "\t\t" + family.outputPriority());
		System.out.println(community.outputName() + "\t\t\t" + community.outputPriority());
		System.out.println(business.outputName() + "\t" + business.outputPriority());
		System.out.println(school.outputName() + "\t\t\t" + school.outputPriority());		
	}
}