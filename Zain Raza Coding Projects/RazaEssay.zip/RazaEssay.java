//*********************************************
// Zain Raza
// 
// RazaEssay.java
// Represents a document that is between 1,500 
// and 3,000 words long.
// 
// Due Thursday, December 13, 2018
//**********************************************

public class RazaEssay extends Document
{
	// member constants 
	final int MIN_WORDS = 1500;
	final int MAX_WORDS = 3000;
	
	//Constructor
	public RazaEssay()
	{

	} 
	
	// Returns whether the value of words falls between minimum and maximum length 
	public boolean validLength()
	{
		if(this.getWords() <= MAX_WORDS && this.getWords() >= MIN_WORDS)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
			
}