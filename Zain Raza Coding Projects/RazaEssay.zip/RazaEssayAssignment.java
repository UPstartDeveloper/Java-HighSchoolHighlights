//***********************************************
// Zain Raza
// 
// RazaEssayAssignment.java
// Demonstrates use of the RazaEssay.java class.
//
// Due: Thursday, December 13, 2018
//***********************************************

public class RazaEssayAssignment
{
	public static void main(String[] args)
	{
//----------------------------------------
// Provides feedback on an English essay.
//----------------------------------------
	
	// instaniation of RazaEssay object and intializing words
	RazaEssay english = new RazaEssay();
	english.setWords(2000);
	
	// output
	System.out.println("This essay has " + english.getWords() + " words.");
	System.out.println("This essay will require " + english.calculatePages() + " pages.");
	if(english.validLength())
	{
		System.out.println("This essay is a valid length.");
	}
	else
	{
		System.out.println("This essay is an invalid lenght.");	
	}
	}
}