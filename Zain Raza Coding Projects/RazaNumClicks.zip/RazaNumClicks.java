import java.awt.*;//application Windows toolkit, includes all subclasses
import javax.swing.*;//required class for GUI
import java.awt.event.*;//allows for event controlled programming

/*
 *Author name: Zain Raza
 *Description: GUI which displays a button that increments to 10 clicks.
 *Due Date: Tuesday December 7, 2017
 */
 
 public class RazaNumClicks extends JFrame implements ActionListener//class declaration
 {
 	JButton button;//counter button
 	int counter=0;//counter variable
 	String text1="You have clicked " + counter + " times";// button text
 	
 	
 	public RazaNumClicks(String title)//constructor
 	{
 		super(title);//initialization
 		button=new JButton(text1);//initialization
 		
 		setLayout(new FlowLayout());//enables text to go left to right
 		
 		add(button);//adding object to program
 		button.setActionCommand(text1);//enabling on click response
 		button.addActionListener(this);//impllements ActionListener interface
 		
 		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//frame exits on close
 	}
 		public void actionPerformed(ActionEvent evt)//button will respond to click
 		{
 			while(evt.getActionCommand().equals(button))//when the button is clicked
 			{
 				counter=counter+1;//increment the counter
 				button.setText(text1);//changes text on screen
 			}
 		}
 	public static void main(String[] args)//main method
 	{
 		RazaNumClicks Clicker=new RazaNumClicks("The Button That Knows All");//creating frame
 		Clicker.setSize(300, 200);//gives dimensions to the frame
 		Clicker.setVisible(true);//makes frame visible to user
 	}
 }