import sys
import random

answer = True#control variable

name=raw_input("What is your name? ")#nuser prompt
#grade=raw_input("%s, what grade are you in? " %name)

random=random.randint(1 , 8)#number generator for deciding output

while(answer):
    question=raw_input("Enter a Y/N question: ")
    if(question!=''):#program begins when user types something
        if (random==1):
            print("It is certain.")#positive
        elif (random==2):
            print("Ask again later")#non-committal
        elif (random==3):
            print("Outlook not so good")#negative
        elif (random==4):
            print("Better not to tell you")#non-committal
        elif (random==5):
            print("It is decidedly so")#positive
        elif (random==6):
            print("Cannot predict now")#non-committal
        elif (random==7):
            print("Very doubtful")#negative
        elif (random==8):
            print("My reply is no")#negative
    else:#user leaves string blank
        sys.exit()#program ends
    change=raw_input("Ask another question? Reply 'yes' or 'no'")#user prompt
    if(change=='yes'):
        answer=True#loop continues
        question=raw_input("Enter a Y/N question: ")
    elif(change=='no'):
        answer=False#loop ends
    else:
        sys.exit()#loop ends
        
    

