public class Bear{//parent class
	String Name;
	
	public class Bear(String n)
		{//1 string parameter, 1 constructor
		Name=n;
	}
	
	public String speak()
	{// 1 method
		return "Roar";
	}
}