birthday = {
    "Abraham Lincoln" : "2/12/1809",
    "George Washington" : "2/22/1732",
    "John F. Kennedy" : "5/29/1917",
    "Franklin Delano Roosevelt" : "1/30/1882",
    "Calvin Coolidge": "4/7/1872" 
}#dictionary for birthdays

print("Welcome to the Presidents' Birthday Dictionary. We know the birthdays of:\n")##user  \nAbraham Lincoln \nCalvin Coolidge \nGeorge Washington \nJohn F. Kennedy \nFranklin D. Roosevelt")#user prompt
print("George Washington\nAbraham Lincoln\nJohn F. Kennedy\n Franklin Delano Roosevelt\nCalvin Coolideg")#intro 
name=raw_input("Whose birthday do you want to look up?\n")##user prompt
#decsion structure
if name in birthday:
    print(name + "'s birthday is " + birthday[name])
else:
    print("Name not in dictionary.")
               
